package com.airlineBooking.System.ticketBooking.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.airlineBooking.System.ticketBooking.controller.dto.AddFlightDto;
import com.airlineBooking.System.ticketBooking.controller.dto.AvailablteTicketDto;
import com.airlineBooking.System.ticketBooking.controller.dto.BookedTicketDto;
import com.airlineBooking.System.ticketBooking.controller.dto.FlightOutput;
import com.airlineBooking.System.ticketBooking.controller.dto.UserDetailDto;
import com.airlineBooking.System.ticketBooking.ticketBookingService.BookTicketService;

@RestController
public class Controller {
	
	@Autowired
	private BookTicketService bookTicketService;
	
	@GetMapping("/getAvailableSeats")
	public AvailablteTicketDto availableTicket(@RequestParam (name = "flightNumber") String flightNo) {
		
		Integer count= bookTicketService.getticket(flightNo);
		AvailablteTicketDto availablteTicketDto=new AvailablteTicketDto();
		
		if(count==0) {
		availablteTicketDto.setCount(0);
		availablteTicketDto.setMessage("Failure");
		return availablteTicketDto;
		}
		
		else {
			availablteTicketDto.setCount(count);
			availablteTicketDto.setMessage("Success");
			return availablteTicketDto;
		}
	}
	
	
	@PostMapping("/bookSeat")
	public BookedTicketDto bookTicket(@RequestBody UserDetailDto userDetailDto)
	{
		
		
		return bookTicketService.bookTicket(userDetailDto);
	}
	
	@PostMapping("/scheduleFlight")
	public FlightOutput addflight(@RequestBody AddFlightDto addFlightDto) {
		
		
		
		return bookTicketService.addflight(addFlightDto);
	}
}
