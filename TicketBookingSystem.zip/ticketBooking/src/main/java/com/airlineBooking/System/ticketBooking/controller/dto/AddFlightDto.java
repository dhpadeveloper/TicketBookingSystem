package com.airlineBooking.System.ticketBooking.controller.dto;

public class AddFlightDto {
	
	private String FlightNumber;
	
	private Integer noOfSeats;

	public String getFlightNumber() {
		return FlightNumber;
	}

	public void setFlightNumber(String flightNumber) {
		FlightNumber = flightNumber;
	}

	public Integer getNoOfSeats() {
		return noOfSeats;
	}

	public void setNoOfSeats(Integer noOfSeats) {
		this.noOfSeats = noOfSeats;
	}
	
	

}
