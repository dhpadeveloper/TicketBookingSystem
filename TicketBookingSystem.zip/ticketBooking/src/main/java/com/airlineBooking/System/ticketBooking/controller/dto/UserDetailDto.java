package com.airlineBooking.System.ticketBooking.controller.dto;

public class UserDetailDto {
	
	private String flightNumber;
	
	private String userName;

	public String getFlightNumber() {
		return flightNumber;
	}

	public void setFlightNumber(String flightNumber) {
		this.flightNumber = flightNumber;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	

}
