package com.airlineBooking.System.ticketBooking.ticketBookingService;

import java.util.HashMap;


import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.airlineBooking.System.ticketBooking.controller.dto.AddFlightDto;
import com.airlineBooking.System.ticketBooking.controller.dto.BookedTicketDto;
import com.airlineBooking.System.ticketBooking.controller.dto.FlightOutput;
import com.airlineBooking.System.ticketBooking.controller.dto.UserDetailDto;

@Service
public class BookTicketService {
	
	HashMap<String, Integer> flightmap=new HashMap<>();
	public BookTicketService() {
		flightmap.put("abc",10);
		flightmap.put("def", 20);
		flightmap.put("gfg", 30);
	}
	
	
	
	
	public Integer getticket(String flightno) {
		
		
		Integer count=flightmap.getOrDefault(flightno, 0);
		
		return count;
	}
	
	public BookedTicketDto bookTicket(UserDetailDto userDetailDto)
	{
		
		Integer count= getticket(userDetailDto.getFlightNumber());
		BookedTicketDto bookedTicketDto=new BookedTicketDto();
		if(count!=0)
		{
			int a=1;
			bookedTicketDto.setSeatnumber(a+"");
			bookedTicketDto.setStatus("Success");
			bookedTicketDto.setMessage("Seat Booked");
			Integer n=flightmap.get(userDetailDto.getFlightNumber());
			flightmap.put(userDetailDto.getFlightNumber(),n-1);
		}
		
		else
		{
			bookedTicketDto.setSeatnumber("No Seat");
			bookedTicketDto.setStatus("Failure");
			bookedTicketDto.setMessage("Tickets full");
		}
		
		return bookedTicketDto;
	}
	
  public FlightOutput addflight(AddFlightDto addFlightDto) {
	  FlightOutput flightOutput=new FlightOutput();
		
	  if(flightmap.containsKey(addFlightDto.getFlightNumber())){
		 
		  flightOutput.setStatus("Failure");
		  flightOutput.setMessage("Flight already exists");
		  return flightOutput;
	  }
	  else {
		  flightmap.put(addFlightDto.getFlightNumber(), addFlightDto.getNoOfSeats());
		  flightOutput.setStatus("Success");
		  flightOutput.setMessage("Flight added");
		  return flightOutput;
	  }
		
		

	}
	
	

}
