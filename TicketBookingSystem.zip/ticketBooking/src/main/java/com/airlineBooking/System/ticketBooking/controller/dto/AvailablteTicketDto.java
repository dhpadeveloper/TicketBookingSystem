package com.airlineBooking.System.ticketBooking.controller.dto;

public class AvailablteTicketDto {
	
	private Integer count;
	
	private String message;

	public Integer getCount() {
		return count;
	}

	public void setCount(Integer count) {
		this.count = count;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
	
	

}
